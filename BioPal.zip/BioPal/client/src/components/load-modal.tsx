import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ChevronRight, FolderOpen } from "lucide-react";
import { type Profile } from "@shared/schema";

interface LoadModalProps {
  isOpen: boolean;
  onClose: () => void;
  profiles: Profile[];
  onLoadProfile: (profile: Profile) => void;
}

export default function LoadModal({ isOpen, onClose, profiles, onLoadProfile }: LoadModalProps) {
  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="w-full max-w-md mx-4" data-testid="modal-load-profiles">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <FolderOpen className="h-5 w-5" />
            <span>Load Saved Profile</span>
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-3 py-4">
          {profiles.length > 0 ? (
            profiles.map((profile) => (
              <div
                key={profile.id}
                className="p-3 border border-border rounded-md hover:bg-accent cursor-pointer transition-colors"
                onClick={() => onLoadProfile(profile)}
                data-testid={`profile-item-${profile.id}`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium text-foreground">{profile.name}</p>
                    <p className="text-sm text-muted-foreground">
                      Saved on {formatDate(profile.updatedAt)}
                    </p>
                  </div>
                  <ChevronRight className="h-4 w-4 text-muted-foreground" />
                </div>
              </div>
            ))
          ) : (
            <div className="p-4 text-center text-muted-foreground border-2 border-dashed border-border rounded-md">
              <FolderOpen className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">No saved profiles yet</p>
            </div>
          )}
        </div>
        
        <div className="flex justify-end space-x-3 pt-4">
          <Button variant="outline" onClick={onClose} data-testid="button-cancel-load">
            Cancel
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
