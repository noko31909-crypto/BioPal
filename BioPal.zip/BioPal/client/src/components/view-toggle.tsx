import { Button } from "@/components/ui/button";
import { Edit, Eye } from "lucide-react";

interface ViewToggleProps {
  currentMode: 'edit' | 'preview';
  onModeChange: (mode: 'edit' | 'preview') => void;
}

export default function ViewToggle({ currentMode, onModeChange }: ViewToggleProps) {
  return (
    <div className="flex justify-center mb-8">
      <div className="bg-muted p-1 rounded-md">
        <Button
          variant={currentMode === 'edit' ? 'default' : 'ghost'}
          size="sm"
          onClick={() => onModeChange('edit')}
          className="text-sm"
          data-testid="button-edit-mode"
        >
          <Edit className="h-4 w-4 mr-2" />
          Edit Mode
        </Button>
        <Button
          variant={currentMode === 'preview' ? 'default' : 'ghost'}
          size="sm"
          onClick={() => onModeChange('preview')}
          className="text-sm"
          data-testid="button-preview-mode"
        >
          <Eye className="h-4 w-4 mr-2" />
          Preview Mode
        </Button>
      </div>
    </div>
  );
}
