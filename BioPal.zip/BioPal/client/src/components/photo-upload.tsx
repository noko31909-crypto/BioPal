import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Upload, User, X } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

interface PhotoUploadProps {
  currentPhotoUrl?: string;
  onPhotoChange: (photoUrl: string) => void;
}

export default function PhotoUpload({ currentPhotoUrl, onPhotoChange }: PhotoUploadProps) {
  const [isUploading, setIsUploading] = useState(false);
  const { toast } = useToast();

  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append('photo', file);
      
      const response = await fetch('/api/upload-photo', {
        method: 'POST',
        body: formData
      });

      if (!response.ok) {
        throw new Error('Failed to upload photo');
      }

      return response.json();
    },
    onSuccess: (data) => {
      onPhotoChange(data.photoUrl);
      toast({
        title: "Success",
        description: "Photo uploaded successfully!",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
    onSettled: () => {
      setIsUploading(false);
    }
  });

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Check file size (5MB limit)
      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: "Error",
          description: "File size must be less than 5MB",
          variant: "destructive",
        });
        return;
      }

      // Check file type
      if (!file.type.startsWith('image/')) {
        toast({
          title: "Error",
          description: "Please select an image file",
          variant: "destructive",
        });
        return;
      }

      setIsUploading(true);
      uploadMutation.mutate(file);
    }
  };

  const handleRemovePhoto = () => {
    onPhotoChange('');
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6 mb-6 shadow-sm">
      <div className="flex items-center space-x-3 mb-4">
        <div className="w-8 h-8 bg-blue-100 rounded-md flex items-center justify-center">
          <User className="text-blue-600 h-4 w-4" />
        </div>
        <h3 className="text-lg font-semibold text-foreground">Profile Picture</h3>
      </div>

      <div className="flex flex-col sm:flex-row gap-6 items-start">
        {/* Photo Preview */}
        <div className="flex-shrink-0">
          <div className="w-32 h-32 rounded-lg border-2 border-dashed border-border flex items-center justify-center overflow-hidden bg-muted">
            {currentPhotoUrl ? (
              <div className="relative w-full h-full">
                <img
                  src={currentPhotoUrl}
                  alt="Profile"
                  className="w-full h-full object-cover rounded-md"
                  data-testid="img-profile-photo"
                />
                <button
                  onClick={handleRemovePhoto}
                  className="absolute top-1 right-1 w-6 h-6 bg-destructive text-destructive-foreground rounded-full flex items-center justify-center hover:bg-destructive/80 transition-colors"
                  data-testid="button-remove-photo"
                >
                  <X className="h-3 w-3" />
                </button>
              </div>
            ) : (
              <div className="text-center">
                <User className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                <p className="text-sm text-muted-foreground">No photo</p>
              </div>
            )}
          </div>
        </div>

        {/* Upload Controls */}
        <div className="flex-1">
          <div className="space-y-4">
            <div>
              <Label htmlFor="photo-upload" className="text-sm font-medium">
                Upload a professional photo
              </Label>
              <p className="text-sm text-muted-foreground mb-2">
                Choose a clear, well-lit photo that represents you professionally. Max file size: 5MB.
              </p>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="relative">
                <Input
                  id="photo-upload"
                  type="file"
                  accept="image/*"
                  onChange={handleFileChange}
                  disabled={isUploading}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                  data-testid="input-photo-upload"
                />
                <Button
                  type="button"
                  variant="outline"
                  disabled={isUploading}
                  className="pointer-events-none"
                  data-testid="button-upload-photo"
                >
                  <Upload className="h-4 w-4 mr-2" />
                  {isUploading ? 'Uploading...' : 'Choose Photo'}
                </Button>
              </div>
              
              {currentPhotoUrl && (
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={handleRemovePhoto}
                  data-testid="button-remove-photo-text"
                >
                  Remove Photo
                </Button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}